# Towards Certified Compositional Compilation for Concurrent Programs

The `concurrency/` directory contains our Coq implementation.

## Main result
The main result of our framework (Theorem 18 in Sec. 7)
is in file `concurrency/framework/Soundness.v`

The compilation correctness proof (Theorem 20 in Sec. 8)
is in file `concurrency/FinalTheorem.v` 

Note that this is a modified version of CompCert 3.0.1.
This modified version is meant to be compiled under configuration
`x86_32-*`
The main modification lies in x86/Op.v and backend/Cminor, where the semantics of comparison are changed to partial ones.
That means we eliminated some undesirable behaviors of intermediate languages.
The original CompCert theorem is unchanged since Clight language and x86 Asm are not changed.

## Installation
To compile coq files in `concurrency/`, we need to install
`ssreflect` library for finite types, and compile CompCert-3.0.1.
The `opam` ocaml package manager is suggested.

### installing ssreflect and coq using opam
The compilation environment could be installed and configured
using following shell commands:

<pre><code>opam init
opam switch 4.04.1
eval `opam config env`
opam repo add coq-released https://coq.inria.fr/opam/released
opam install coq-mathcomp-ssreflect</code></pre>

Opam will install all dependencies (including `Coq`) for you.

### compile 
`./configure x86_32-linux` for linux or 
`./configure x86_32-cygwin` for cygwin or
`./configure x86_32-macosx` for osx

(You may find some dependencies missing. 
If so, install the missing part and re-run this command.)

`make`


### developing using Emacs
You may need to install `ProofGeneral` first.
Then you could change the workign directory to `CompCert-3.0.1`
and run `./pg` (or `./pg_mac` if you use mac osx and Emacs application),
it will open `emacs` with the coq directories automatically set.


