#!/bin/bash

cp concurrency/*.glob ./html
cp concurrency/common/*.glob ./html
cp concurrency/framework/*.glob ./html
cp concurrency/framework/Compositionality/*.glob ./html
cp concurrency/framework/NPDefs/*.glob ./html
cp concurrency/framework/GlobUSim/*.glob ./html
cp concurrency/framework/GlobDSim/*.glob ./html
cp concurrency/comp_correct/*.glob ./html
cp concurrency/comp_correct/phases/*.glob ./html