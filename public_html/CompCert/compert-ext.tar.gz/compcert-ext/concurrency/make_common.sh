#!/bin/bash -x

coqc -R ../ compcert common/Memperm.v
coqc -R ../ compcert common/Blockset.v
coqc -R ../ compcert common/GMemory.v
coqc -R ../ compcert common/Footprint.v

coqc -R ../ compcert common/MemAux.v
coqc -R ../ compcert common/MemClosures.v

coqc -R ../ compcert common/InteractionSemantics.v

coqc -R ../ compcert common/GAST.v
coqc -R ../ compcert common/ETrace.v
coqc -R ../ compcert common/GlobDefs.v
coqc -R ../ compcert common/GlobSemantics.v

coqc -R ../ compcert common/DRF.v

coqc -R ../ compcert common/Injections.v
coqc -R ../ compcert common/LDSimDefs.v
coqc -R ../ compcert common/LDSim.v
coqc -R ../ compcert common/ReachClose.v
coqc -R ../ compcert common/SeqCorrect.v

