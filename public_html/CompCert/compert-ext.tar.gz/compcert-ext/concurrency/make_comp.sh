#!/bin/bash -x
coqc -R ../ compcert comp_correct/ClightLang.v
coqc -R ../ compcert comp_correct/ClightWD.v
coqc -R ../ compcert comp_correct/ClightRC.v

coqc -R ../ compcert comp_correct/AsmLang.v
coqc -R ../ compcert comp_correct/AsmWD.v
coqc -R ../ compcert comp_correct/AsmDET.v

# Compilation Pases
coqc -R ../ compcert comp_correct/phases/simpl_locals.v
coqc -R ../ compcert comp_correct/phases/simpl_locals_proof.v

# Compiler Correctness
coqc -R ../ compcert comp_correct/CompCorrect.v

# Primitive module
coqc -R ../ compcert comp_correct/PrimitiveMod.v
# Export Language Properties
coqc -R ../ compcert comp_correct/LangProps.v
