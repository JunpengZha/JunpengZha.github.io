#!/bin/bash -x

# NP sem 
coqc -R ../ compcert framework/NPDefs/NPSemantics.v
coqc -R ../ compcert framework/NPDefs/NPDRF.v
coqc -R ../ compcert framework/NPDefs/NPEquiv.v
# Global upward simulation
coqc -R ../ compcert framework/GlobUSim/GSimDefs.v
coqc -R ../ compcert framework/GlobUSim/GlobUSim.v
coqc -R ../ compcert framework/GlobUSim/SimRefine.v
coqc -R ../ compcert framework/GlobUSim/SimDRF.v
coqc -R ../ compcert framework/GlobUSim/GlobUSimRefine.v
# removed, substituted by SimRefine.v, GLobUSimRefine.v and SimDRF.v
# coqc -R ../ compcert framework/GlobUSim/SimSound.v

# Global downward simulation
coqc -R ../ compcert framework/GlobDSim/GlobDSim.v
coqc -R ../ compcert framework/GlobDSim/Flipping.v
coqc -R ../ compcert framework/GlobDSim/GlobSim.v
# Compositionality
coqc -R ../ compcert framework/Compositionality/AuxLDSim.v
coqc -R ../ compcert framework/Compositionality/Compositionality.v
# soundness
coqc -R ../ compcert framework/Soundness.v
# transitivity
coqc -R ../ compcert framework/Transitivity.v
