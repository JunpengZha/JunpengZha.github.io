#!/bin/bash

## Common definitions
./make_common.sh
## Framework
./make_framework.sh
## Compiler
./make_comp.sh
## Final Theorem
coqc -R ../ compcert FinalTheorem.v
