#!/bin/sh

coqwc concurrency/common/FMemOpFP.v concurrency/comp_correct/localize/MemOpFP.v concurrency/comp_correct/localize/ValFP.v