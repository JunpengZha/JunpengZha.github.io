#!/bin/bash

coqdep -R ./concurrency compcert concurrency/FinalTheorem.v -dumpgraph final_full_tmp.dot
cat final_full_tmp.dot | sed "s#./[^ ]*/##g" > final_full.dot
rm final_full_tmp.dot
dot -Tsvg final_full.dot > final_full.svg
