int main (int x, int y)
{
  return x == 0 ? x : y == 0 ? y;
}
