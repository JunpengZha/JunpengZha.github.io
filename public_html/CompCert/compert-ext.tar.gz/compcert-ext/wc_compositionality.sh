coqwc concurrency/framework/Compositionality/Compositionality.v \
concurrency/framework/Compositionality/AuxLDSim.v \
concurrency/framework/Compositionality/Invs.v