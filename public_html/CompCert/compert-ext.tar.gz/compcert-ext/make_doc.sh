#!/bin/bash

coqdoc -R . compcert --files-from myfiles -d ./html -toc