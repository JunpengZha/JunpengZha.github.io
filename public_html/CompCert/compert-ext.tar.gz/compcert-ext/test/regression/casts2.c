#include <stdint.h>
#include <stdio.h>

uint16_t func_46(void)
{
    int8_t l_48 = 0xA0;
    return l_48;
}

int main(void)
{
    int32_t t_3 = 0;
    t_3 = func_46();
    printf("t_3 = %d\n", t_3);
    return 0;
}
