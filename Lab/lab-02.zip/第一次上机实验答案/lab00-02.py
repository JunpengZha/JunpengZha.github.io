def sum_square(a,b):
    return (a * a + b * b)
