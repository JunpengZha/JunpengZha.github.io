def explicit_apply_n_times(f, n, x):
    while (n > 0):
        x = f(x)
        n = n - 1
    return x

def apply_n_times(f, n):
    return lambda x : explicit_apply_n_times(f, n, x)
