def factorial(n):
    s = 1;
    while (n>0):
        s = s * n
        n = n - 1
    return s
